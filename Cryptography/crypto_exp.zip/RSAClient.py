import math
 
 
def gcd(a, h):
    temp = 0
    while(1):
        temp = a % h
        if (temp == 0):
            return h
        a = h
        h = temp
 
 
p = 3
q = 7
n = p*q
e = 2
phi = (p-1)*(q-1)
while (e < phi):
 
    if(gcd(e, phi) == 1):
        break
    else:
        e = e+1
 

 
k = 2
d = (1 + (k*phi))/e
import socket
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(('127.0.0.1', 8080))
print("ENTER MESSAGE")

msg=int(input())
c = pow(msg, e)
c = math.fmod(c, n)
print("Encrypted data = ", c) 
c=str(c)
client.send(c.encode())
from_server = client.recv(4096)
client.close()

