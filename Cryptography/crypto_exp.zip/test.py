import numpy as np 

key = [[6,24,1],[13,16,10],[20,17,15]]
A = np.array(key)

cipher = [[15],[14],[17]]
key_inv=np.linalg.inv(A)

ans=[]
for i in key_inv:
    for ind in i.length:
        print(i[ind])