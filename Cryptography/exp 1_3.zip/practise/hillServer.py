import socket
import numpy as np

def matrix_inverse_mod26(matrix):
    det = int(np.round(np.linalg.det(matrix)))
    inv_det = pow(det, -1, 26)
    #det * inv gives the adjoint matrix 
    #inv_det * (det * inv) mod 26 gives us the inverse of key matrix in modular arithmetic 
    adj = np.round(inv_det * np.linalg.inv(matrix) * det) % 26
    return adj.astype(int)

def decrypt(msg, key):
    msg_matrix = np.array([ord(ch) - ord('a') for ch in msg])
    msg_matrix = msg_matrix.reshape(len(key), -1)

    key_matrix = matrix_inverse_mod26(key)
    key_matrix = np.array(key_matrix)
    result_matrix = (key_matrix @ msg_matrix) % 26
    plaintext = "".join([chr(ord('a') + num) for num in result_matrix.flat])

    return plaintext


host = "127.0.0.1"
port = 5842
socket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
socket.bind((host,port))
socket.listen()
client_socket,addr = socket.accept()
msg = client_socket.recv(1024).decode()
print("Received Message:",msg)
matrix_str = client_socket.recv(1024).decode()

# Split the string into rows and parse it into a matrix
key = [list(map(int, row.split())) for row in matrix_str.split("\n")]
print(decrypt(msg,key))


