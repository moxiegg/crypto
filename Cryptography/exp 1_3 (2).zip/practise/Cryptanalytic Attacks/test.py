try:
    pow(13,-1,26)
except:
    print("-------------------------------\nModular Inverse Does not Exist")
